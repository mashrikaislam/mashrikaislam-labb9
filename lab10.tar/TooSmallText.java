import java.io.IOException;

public class TooSmallText extends Exception {
    public TooSmallText(String message) {
        super(message);
    }
}
