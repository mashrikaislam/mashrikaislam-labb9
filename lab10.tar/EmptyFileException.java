import java.io.IOException;


public class EmptyFileException extends IOException {
    public EmptyFileException(String message) {
        super(message);  // pass the string to IOException's constructor
    }
}
