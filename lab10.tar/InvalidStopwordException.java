

public class InvalidStopwordException extends Exception {
    public InvalidStopwordException(String message) {
        super(message);  // pass the message to the parent Exception class
    }
}
